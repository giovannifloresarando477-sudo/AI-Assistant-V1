# Mi Asistente — V1

Primera versión de un asistente Android.

## Incluye

- Entrada de texto.
- Reconocimiento de voz.
- Abrir YouTube.
- Abrir navegador.
- Abrir Maps.
- Crear una alarma mediante el Intent oficial de Android.
- Preparar un SMS en la aplicación de mensajes.
- Arquitectura separada entre interpretación y ejecución.

## Importante

Esta V1 usa un intérprete local sencillo (`AssistantBrain`) para poder probar la aplicación sin una API externa.

La siguiente versión puede conectar un modelo de IA mediante un backend seguro y convertir órdenes naturales en acciones estructuradas.

No pongas una clave privada de OpenAI dentro de una APK publicada. Para una aplicación real, la clave debe permanecer en un servidor/backend.

## Ejemplos

- "Abre YouTube"
- "Abre el navegador"
- "Abre Maps"
- "Pon una alarma a las 7"
- "Pon una alarma a las 7:30 pm"
- "Enviar mensaje: Hola, llego en 10 minutos"

## Compilación

El proyecto usa Kotlin + Android Gradle Plugin.

JDK recomendado: 17.
Compile SDK: 35.
Min SDK: 26.
