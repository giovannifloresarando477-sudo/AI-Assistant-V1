package com.example.aiassistant

import java.util.Locale

enum class AssistantAction {
    OPEN_YOUTUBE,
    OPEN_BROWSER,
    OPEN_MAPS,
    SET_ALARM,
    SEND_SMS,
    CHAT
}

data class AssistantResult(
    val action: AssistantAction,
    val reply: String,
    val hour: Int? = null,
    val minute: Int? = null,
    val message: String? = null,
    val phone: String? = null
)

object AssistantBrain {

    fun interpret(raw: String): AssistantResult {
        val text = raw.trim()
            .lowercase(Locale.getDefault())

        return when {
            text.contains("youtube") ->
                AssistantResult(
                    AssistantAction.OPEN_YOUTUBE,
                    "Abriendo YouTube."
                )

            text.contains("navegador") ||
            text.contains("google") ||
            text.contains("internet") ->
                AssistantResult(
                    AssistantAction.OPEN_BROWSER,
                    "Abriendo el navegador."
                )

            text.contains("maps") ||
            text.contains("mapa") ->
                AssistantResult(
                    AssistantAction.OPEN_MAPS,
                    "Abriendo Maps."
                )

            text.contains("alarma") ->
                parseAlarm(text)

            text.startsWith("mensaje") ||
            text.contains("enviar mensaje") ||
            text.contains("sms") ->
                AssistantResult(
                    AssistantAction.SEND_SMS,
                    "Voy a abrir la aplicación de mensajes para preparar el mensaje. No lo enviaré automáticamente.",
                    message = extractMessage(raw)
                )

            else ->
                AssistantResult(
                    AssistantAction.CHAT,
                    "Puedo abrir YouTube, el navegador o Maps, y programar alarmas. También puedo preparar un mensaje de texto."
                )
        }
    }

    private fun parseAlarm(text: String): AssistantResult {
        val regex = Regex("""(\d{1,2})(?:[:.](\d{1,2}))?\s*(am|pm)?""")
        val match = regex.find(text)

        if (match == null) {
            return AssistantResult(
                AssistantAction.CHAT,
                "Dime la hora. Por ejemplo: «pon una alarma a las 7:30»."
            )
        }

        var hour = match.groupValues[1].toInt()
        val minute = match.groupValues[2].ifBlank { "0" }.toInt()
        val period = match.groupValues[3]

        if (period == "pm" && hour < 12) hour += 12
        if (period == "am" && hour == 12) hour = 0

        if (hour !in 0..23 || minute !in 0..59) {
            return AssistantResult(
                AssistantAction.CHAT,
                "La hora no parece válida."
            )
        }

        return AssistantResult(
            AssistantAction.SET_ALARM,
            "Preparando una alarma para %02d:%02d.".format(hour, minute),
            hour = hour,
            minute = minute
        )
    }

    private fun extractMessage(raw: String): String {
        val marker = "mensaje"
        val index = raw.lowercase(Locale.getDefault()).indexOf(marker)

        if (index >= 0) {
            val value = raw.substring(index + marker.length)
                .trim()
                .removePrefix(":")
                .trim()

            if (value.isNotBlank()) return value
        }

        return "Hola."
    }
}
