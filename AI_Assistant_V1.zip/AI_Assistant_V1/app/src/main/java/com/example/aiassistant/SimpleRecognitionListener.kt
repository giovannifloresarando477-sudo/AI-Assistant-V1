package com.example.aiassistant

import android.os.Bundle
import android.speech.RecognitionListener

class SimpleRecognitionListener(
    private val onReady: () -> Unit,
    private val onResult: (String) -> Unit,
    private val onError: () -> Unit
) : RecognitionListener {

    override fun onReadyForSpeech(params: Bundle?) = onReady()
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onResults(results: Bundle?) {
        val values = results?.getStringArrayList(
            RecognitionListener.RESULTS_RECOGNITION
        )
        val text = values?.firstOrNull()

        if (text != null) onResult(text) else onError()
    }

    override fun onError(error: Int) = onError()
}
