package com.example.aiassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.widget.Toast

class ActionExecutor(private val context: Context) {

    fun execute(result: AssistantResult) {
        when (result.action) {
            AssistantAction.OPEN_YOUTUBE -> openApp(
                "com.google.android.youtube"
            )

            AssistantAction.OPEN_BROWSER -> openUrl(
                "https://www.google.com"
            )

            AssistantAction.OPEN_MAPS -> openUrl(
                "geo:0,0?q=La+Paz+Bolivia"
            )

            AssistantAction.SET_ALARM -> {
                val hour = result.hour ?: return
                val minute = result.minute ?: return

                val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(AlarmClock.EXTRA_HOUR, hour)
                    putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    putExtra(
                        AlarmClock.EXTRA_MESSAGE,
                        "Alarma creada por Mi Asistente"
                    )
                }

                if (intent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(intent)
                } else {
                    toast("No encontré una aplicación de alarma.")
                }
            }

            AssistantAction.SEND_SMS -> {
                val message = result.message ?: ""
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("smsto:")
                    putExtra("sms_body", message)
                }

                if (intent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(intent)
                } else {
                    toast("No encontré una aplicación de mensajes.")
                }
            }

            AssistantAction.CHAT -> Unit
        }
    }

    private fun openApp(packageName: String) {
        val intent = context.packageManager
            .getLaunchIntentForPackage(packageName)

        if (intent != null) {
            context.startActivity(intent)
        } else {
            toast("La aplicación no está instalada.")
        }
    }

    private fun openUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))

        if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
        } else {
            toast("No hay una aplicación compatible.")
        }
    }

    private fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
