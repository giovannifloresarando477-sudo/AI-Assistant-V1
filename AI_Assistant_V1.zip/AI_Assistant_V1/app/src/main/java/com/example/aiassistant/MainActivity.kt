package com.example.aiassistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var input: EditText
    private lateinit var chat: TextView
    private lateinit var status: TextView
    private lateinit var executor: ActionExecutor
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.inputText)
        chat = findViewById(R.id.chatText)
        status = findViewById(R.id.statusText)

        executor = ActionExecutor(this)

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            processInput(input.text.toString())
        }

        findViewById<Button>(R.id.micButton).setOnClickListener {
            startVoiceInput()
        }
    }

    private fun processInput(command: String) {
        if (command.isBlank()) return

        addChat("Tú: $command")
        input.text.clear()

        val result = AssistantBrain.interpret(command)

        if (result.action == AssistantAction.CHAT) {
            addChat("Asistente: ${result.reply}")
            return
        }

        addChat("Asistente: ${result.reply}")
        executor.execute(result)
    }

    private fun addChat(text: String) {
        chat.append("\n$text\n")
    }

    private fun startVoiceInput() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                100
            )
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "El reconocimiento de voz no está disponible."
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        speechRecognizer?.setRecognitionListener(
            SimpleRecognitionListener(
                onReady = { status.text = "Escuchando..." },
                onResult = { text ->
                    status.text = "Procesando..."
                    input.setText(text)
                    processInput(text)
                    status.text = "Listo."
                },
                onError = {
                    status.text = "No pude reconocer la voz."
                }
            )
        )

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }

        speechRecognizer?.startListening(intent)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}
